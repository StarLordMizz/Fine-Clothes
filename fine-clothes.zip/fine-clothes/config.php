<?php

require('stripe-php/init.php');

$pub_key="pk_test_51JY0PiBiomufw1u7YEu2GRq2p8MVtdE72B9ne7Wtp24qTpRQGzZeF8IuAwmkbV5eXhcmM2XNfUrz7BjfFhJXD2VX00TB6iLul0";
$sec_key="sk_test_51JY0PiBiomufw1u7DT47HsmifQvjFNbdWMmAt5hbSG7fD3U9cdOYP3wDFW540VmvSJ52euQeEPAImEtQzwNpGNCD00p9ayRuk7";
\Stripe\Stripe::setApiKey($sec_key);

?>