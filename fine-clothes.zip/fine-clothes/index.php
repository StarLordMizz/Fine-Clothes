   
	<?php include "inc/header.php"; ?>
	
	<!---Slider Starts--->
	<?php include "inc/slider.php"; ?>
 
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-12 no-padding m-b-30">
					<div class="col-sm-3 text-center ">
						<div class="card-sec">
							<img src="images/carparts-home-icon1.png">
							<h4>30 days return</h4>
							<p>Vivamus in diam turpis. In quis nibh magna maximus tristique.</p>
						</div>
					</div>
					
					<div class="col-sm-3 text-center ">
						<div class="card-sec">
						<img src="images/carparts-home-icon2.png">
						<h4>Free shipping</h4>
						<p>Sed ultrices nisl velit, eu ornare est ullamcorper quis magna.</p>
					</div>
					</div>

					<div class="col-sm-3 text-center ">
						<div class="card-sec">
						<img src="images/carparts-home-icon3.png">
						<h4>Quick delivery</h4>
						<p>Maecenas imperdiet ante eget hendrerit posuere urna.</p>
					</div>
					</div>
					<div class="col-sm-3 text-center ">
						<div class="card-sec">
						<img src="images/carparts-home-icon4.png">
						<h4>Safe packages</h4>
						<p>Vivamus in diam turpis. In quis nibh magna maximus tristique.</p>
					</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section>
		<div class="container">
			<div class="row">
			<!---Sidebar Starts--->
				  <?php include "inc/sidebar.php"; ?>
		 <!---Sidebar Ends--->
				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Features Items</h2>
				        <?php
						$select = "select * from product ORDER BY RAND() LIMIT 0,6";
						$run = mysqli_query($con,$select);
						while($row=mysqli_fetch_array($run)){
							$id = $row['id'];
							$name = $row['p_name'];
							$image = $row['p_image'];
							$price = $row['p_price'];
							$qty = $row['p_qty'];
						?>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<div class="p-image">
										<a href="product_details.php?pid=<?php echo $row['id'];?>" class='' id='$id'>
										<img src="admin/images/<?php echo $image; ?>" alt="" ></a>
									</div>
										<h2><span>$</span><?php echo $price; ?></h2>
										<p><?php echo $name;  ?></p>
										

									
										



										<?php


        if ($qty == 0){
           
            echo '
			<p>out of stock </p>
                <input 
				class="btn btn-default add-to-cart"
                    type="button" 
                    value="Sold Out" 
                    onclick="cart('.$row['id'].')" 
                    disabled
                />';
        }else{
           echo' <p>In stock   </p> <input class="btn btn-default add-to-cart" type="button" value="Add to Cart"  onclick="cart('.$row['id'].')"  />';
        }
?>
		
																			</div>
									
 								</div>
								
							</div>
						</div>
						<?php } ?>
						
						
					</div><!--features_items-->
				
					
					
				</div>
			</div>
		</div>
	</section>


	<section>
		<div class="container">
			<div class="row partener">
				<div class="col-sm-12 no-padding m-b-30">
					<h2 class="title text-center">Our Partener</h2>
					<div class="col-sm-3 text-center ">
						<div class="card-sec">
							<img src="images/logo-16.png">
						</div>
					</div>
					
					<div class="col-sm-3 text-center ">
						<div class="card-sec">
						<img src="images/logo-14.png">
						
					</div>
					</div>

					<div class="col-sm-3 text-center ">
						<div class="card-sec">
						<img src="images/logo-13.png">
						
					</div>
					</div>
					<div class="col-sm-3 text-center ">
						<div class="card-sec">
						<img src="images/logo-12.png">
						
					</div>
					</div>
				</div>
			</div>
		</div>
	</section>


  <!---Footer Starts--->
	<?php include "inc/footer.php"; ?>
	<!---Footer Ends--->
<script>
	 
		function cart($pro_id){
		var p_id = $pro_id;
		
		$.ajax({
			url:"function.php",
			method:"post",
			data:{p_id:p_id},
			success: function($data){
			    if($data > 0){
					notif({
						msg:"Product Already Added !!!",
						type:"warning",
						width:330,
						height:40,
						timeout:1000,
						
					})
					
				}else {
					notif({
						msg:"Add to cart",
						type:"success",
						width:330,
						height:40,
						timeout:1000,
						
					})
				}
				   	
			}
			
		})
		
	}

	</script>
	<?php
	if(isset($_GET['logout'])){
		echo "<script>
		window.open('index.php','_self')
		alert('You have logged out successfully')</script>";
		
	}
	
	if(isset($_GET['login'])){
		echo "<script>
		window.open('index.php','_self')
		alert('login successfully')

					</script>
		";
		
	}

		
	
 
	
	
	?>


