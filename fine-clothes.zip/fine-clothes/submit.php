<?php

 include "db/connection.php";
require('config.php');

 
if(isset($_POST['stripeToken']))
{
 
\Stripe\Stripe::setVerifySslCerts(false);


     $token = $_POST['stripeToken'];
     $d_name=$_POST['d_name'];
     $d_city=$_POST['d_city'];
     $d_address=$_POST['d_address'];

    
      
     

}

 

?>

<html>

</body>
<head>
<link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<style>
 
@import url(http://fonts.googleapis.com/css?family=Montserrat);
 * {
margin: 0;
padding: 0;
}
html {
height: 100%;
 background: url('http://thecodeplayer.com/uploads/media/gs.png');
 background: linear-gradient(rgba(196, 102, 0, 0.2), rgba(155, 89, 182, 0.2)),  url('http://thecodeplayer.com/uploads/media/gs.png');
}
body {
font-family: montserrat, arial, verdana;
}
 #msform {
width: 400px;
margin: 50px auto;
text-align: center;
position: relative;
}
#msform fieldset {
background: white;
border: 0 none;
border-radius: 3px;
box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
padding: 20px 30px;
box-sizing: border-box;
width: 80%;
margin: 0 10%;
 position: absolute;
}
 #msform fieldset:not(:first-of-type) {
display: none;
}
 #msform input, #msform textarea {
padding: 15px;
border: 1px solid #ccc;
border-radius: 3px;
margin-bottom: 10px;
width: 100%;
box-sizing: border-box;
font-family: montserrat;
color: #2C3E50;
font-size: 13px;
}
 #msform .action-button {
width: 100px;
background: #27AE60;
font-weight: bold;
color: white;
border: 0 none;
border-radius: 1px;
cursor: pointer;
padding: 10px 5px;
margin: 10px 5px;
}
#msform .action-button:hover, #msform .action-button:focus {
box-shadow: 0 0 0 2px white, 0 0 0 3px #27AE60;
}
 .fs-title {
font-size: 15px;
text-transform: uppercase;
color: #2C3E50;
margin-bottom: 10px;
}
.fs-subtitle {
font-weight: normal;
font-size: 13px;
color: #666;
margin-bottom: 20px;
}
 #progressbar {
margin-bottom: 30px;
overflow: hidden;
 counter-reset: step;
}
#progressbar li {
list-style-type: none;
color: white;
text-transform: uppercase;
font-size: 9px;
width: 33.33%;
float: left;
position: relative;
}
#progressbar li:before {
content: counter(step);
counter-increment: step;
width: 20px;
line-height: 20px;
display: block;
font-size: 10px;
color: #333;
background: white;
border-radius: 3px;
margin: 0 auto 5px auto;
}
 #progressbar li:after {
content: '';
width: 100%;
height: 2px;
background: white;
position: absolute;
left: -50%;
top: 9px;
z-index: -1;
}
#progressbar li:first-child:after {
 content: none;
}
 
#progressbar li.active:before, #progressbar li.active:after {
background: #27AE60;
color: white;
}

.submit{
	width:300px;
	padding:2px;
}
</style>
</head>

<form id="msform">

<fieldset>

<?php 
				$total = 0;
				$sel = "select * from cart where session_id='$cookie_id'";
				$run = mysqli_query($con,$sel);
				$count_cart = mysqli_num_rows($run);
				while($row=mysqli_fetch_array($run)){
					$p_id = $row['p_id'];
					$p_title = $row['p_title'];
					$p_image = $row['p_image'];
					$p_price = $row['p_price'];
					$p_qty = $row['p_qty'];
					
					
					$total += ($p_price * $p_qty);
				}
				
				$random = mt_rand(1000,10000000);
				
				$get_user = "select c_id from customer where c_email ='$s_email'";
				$run_get = mysqli_query($con,$get_user);
				$get = mysqli_fetch_array($run_get);
				$u_id = $get['c_id'];

                $data=\Stripe\Charge::create(array(
                    "amount"=>$total*100,
                    "currency"=>"cad",
                    "source"=>$token,
                ));
				
?>

<script src="js/jquery.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
 <script src="js/jquery.easing.min.js" type="text/javascript"></script> 

 
<script>
  
 $(document).ready(function () {
        
        var order_id = "<?php echo $random; ?>";
	 var u_id = "<?php echo $u_id; ?>";
	  var total = "<?php echo $total; ?>";
	 var d_name = "<?php echo $d_name; ?>";
	 var d_city = "<?php echo $d_city; ?>";
	 var d_address ="<?php echo $d_address; ?>";

 	
	 setTimeout(function(){
	   $.ajax({
		   url:"payment.php",
		   method:"post",
		   data:{order_id:order_id,u_id:u_id,d_name:d_name,d_city:d_city,d_address:d_address,total:total},
		   success($data){
			   if($data < 1){
				   $.ajax({
					   url:"payment.php",
					   method:"post",
					   data:{order:order_id},
					   success: function($confirm){
						   if($confirm > 0){
							   setTimeout(function(){ window.location.href = "index.php?thank"; }, 1000);
							    
						   }
					   }
					   
				   })
			   }
		   }
	   });
     },1500);
	
	
       
    });
 
</script>

<h2 class="fs-title">Confirmation</h2>
<h3 class="fs-subtitle">Your Order Has been Confirmed</h3>
<h1>Your Order ID is </h1><br><h2><?php echo $random; ?></h2><br>

</fieldset>

</form>



</body>
</html>