-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2021 at 01:49 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `main_fineclothes`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `title`) VALUES
(1, 'Tommy Hilfigher'),
(22, 'Fine-Original');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `p_title` varchar(1000) NOT NULL,
  `p_image` varchar(1000) NOT NULL,
  `p_price` varchar(1000) NOT NULL,
  `p_qty` int(11) NOT NULL,
  `session_id` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `p_title`, `p_image`, `p_price`, `p_qty`, `session_id`) VALUES
(25, 1, 'effeer', 'a.jpg', '200', 1, 'p030b5ti40ku53tg4vb52c3kv2'),
(28, 60, 'Women Block Print Cut Kurta', 'women-2.png', '900', 1, 'nbvsj1mviesektjmhptv30spbl'),
(29, 61, 'Women Printed Rayon Flared Kurta', 'women-3.png', '850', 1, 'nbvsj1mviesektjmhptv30spbl'),
(36, 60, 'Women Block Print Cut Kurta', 'women-2.png', '900', 1, 'edb0urmb8ghpqc5p6597umm4qj'),
(37, 59, 'Women Printed Pure Cotton Straight Kurta ', 'women-1.png', '945', 1, '33ng15h657fk0idj1nu7vb1pvm'),
(38, 132323, 'regeg', 'a.jpg', '3300', 1, 'bm8cl1in4pirjjv6jrfeovdvkm'),
(40, 58, 'Men Mandarin Collar  Black T-Shirt', 'product-3.png', '549', 1, 'fuavp4i2l1nifm34ej9oe8jl90'),
(43, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'kj375k5lbvap95mdeatjmgvgn4'),
(44, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'bk3tahnkh1pq2dg39bbjrq61vu'),
(45, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, '5qhsol0cb9450pgdj4n9rqjvgg'),
(46, 63, 'Slim Men Grey Jeans', 'jens-1.png', '1800', 1, '5qhsol0cb9450pgdj4n9rqjvgg'),
(54, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'jmmbcavrfkphsn6k4p8dsqm5oj'),
(57, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, '8dva1n8ehvveopsfu0ubma9td3'),
(58, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, '1npdrh5konpjegdo16l58knv7g'),
(59, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'og1q9ht686bus8gar9ql1r4a6e'),
(60, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'oded6511jnj9r6rnb7ausbr3bp'),
(61, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'ifufuqvqisrv6a833f2k4usovl'),
(62, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'jiv9aovfhtgr31kg8q2lqpm5ep'),
(63, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'd1rh73moh7kgjrlnpjbr7ho5d9'),
(65, 34456465, 'terere', 'a.jpg', '350', 1, '5hur8spf7up04fsa2bhcuntlmk'),
(100, 34456465, 'terere', 'a.jpg', '350', 1, 'ca7c78f293f459a57f35348b1baa965e'),
(101, 1, 'Solid Men Polo Neck Green T-Shirt', 'product-1.png', '200', 1, 's9c0u7iu01jiih6fbr4ebv87ht'),
(102, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'rqedhvch8jok9l62oud9j52ue6'),
(104, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'd5h8fvgeib2mi65ircmp6loa5t'),
(105, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'tci4quia7mber505l7tt8q2qsh'),
(106, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, '44urtouh2lr7n9e7qldvls72rp'),
(107, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'bfic99buf5ek0i37ib2ioctrlq'),
(108, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'qnj25323hcrfvtjhgfi455vbsa'),
(109, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, '8ncg1m3sn26f8euhccq7i6tcu7'),
(110, 63, 'Slim Men Grey Jeans', 'jens-1.png', '1800', 1, '8ncg1m3sn26f8euhccq7i6tcu7'),
(111, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'nsd74kuv3vl7smiidgu6b5vaj5'),
(112, 63, 'Slim Men Grey Jeans', 'jens-1.png', '1800', 1, 'nsd74kuv3vl7smiidgu6b5vaj5'),
(114, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'qiu00ep1d90795vbhja1lqcs87'),
(115, 63, 'Slim Men Grey Jeans', 'jens-1.png', '1800', 1, 'qiu00ep1d90795vbhja1lqcs87'),
(116, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, '0hge975reogjjnb29e8nr4hdon'),
(117, 63, 'Slim Men Grey Jeans', 'jens-1.png', '1800', 1, '0hge975reogjjnb29e8nr4hdon'),
(118, 64, 'Slim Men Grey Jeans', 'jens-2.png', '2500', 1, 'qf3o0v4bic859jt9n82h0fdvog');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Men'),
(2, 'Women');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `message`) VALUES
(2, 'manna', 'aa@gmail.com', 'this is my first message'),
(3, 'manna', 'aa@gmail.com', 'this is my second message'),
(5, 'sanjay', 'sujay@gmail.com', 'Hi'),
(6, 'sanjay', 'sujay@gmail.com', 'Hi'),
(7, 'sanjay', 'sujay@gmail.com', 'Hi'),
(8, 'hero', 'hero1@gmail.com', 'Hi hello');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `c_id` int(250) NOT NULL,
  `c_session` varchar(200) NOT NULL,
  `c_name` varchar(200) NOT NULL,
  `c_email` varchar(200) NOT NULL,
  `c_pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_id`, `c_session`, `c_name`, `c_email`, `c_pass`) VALUES
(9, '82t34fm6938vkvdckesgpr58ac', 'gggg', 'aa@gmail.com', '12345123456'),
(11, '82t34fm6938vkvdckesgpr58ac', 'mandsdsd', 'mss@gmail.com', '123456'),
(12, '82t34fm6938vkvdckesgpr58ac', 'abcdd', 'f@gmail.com', '123456'),
(14, '82t34fm6938vkvdckesgpr58ac', 'mmm', 'm@gmail.com', '123123'),
(15, '82t34fm6938vkvdckesgpr58ac', 'ww', 'ds@gmail.com', '123123'),
(16, '82t34fm6938vkvdckesgpr58ac', 'jj', 'jj@gmail.com', '123123'),
(17, '82t34fm6938vkvdckesgpr58ac', 'ram@gmail.com', 'ram@gmail.com', '123456'),
(18, '82t34fm6938vkvdckesgpr58ac', 'abcd', 'abcd@gmail.com', '123456'),
(19, '82t34fm6938vkvdckesgpr58ac', 'aaa@gmail.com', 'aaa@gmail.com', '123456'),
(20, '82t34fm6938vkvdckesgpr58ac', 'a21@gmail.com', 'a21@gmail.com', '123456'),
(21, '82t34fm6938vkvdckesgpr58ac', 'a21', 'a22@gmail.com', '123456'),
(22, '82t34fm6938vkvdckesgpr58ac', 'nn', 'n@gmail.com', '123123'),
(23, '82t34fm6938vkvdckesgpr58ac', 'tt new', 'tt@gmail.com', '123123'),
(24, '82t34fm6938vkvdckesgpr58ac', 'mizan', 'mizan@gmail.com', '1234567');

-- --------------------------------------------------------

--
-- Table structure for table `forgotrequest`
--

CREATE TABLE `forgotrequest` (
  `id` int(11) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forgotrequest`
--

INSERT INTO `forgotrequest` (`id`, `uname`, `email`) VALUES
(1, 'aa', 'aa@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `offerproducts`
--

CREATE TABLE `offerproducts` (
  `id` int(11) NOT NULL,
  `p_name` varchar(259) NOT NULL,
  `p_category` varchar(250) NOT NULL,
  `p_sub` varchar(250) NOT NULL,
  `p_brand` varchar(250) NOT NULL,
  `p_price` int(11) NOT NULL,
  `d_price` int(11) NOT NULL,
  `m_price` int(11) NOT NULL,
  `p_desc` varchar(5000) NOT NULL,
  `p_qty` int(11) NOT NULL,
  `p_image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `offerproducts`
--

INSERT INTO `offerproducts` (`id`, `p_name`, `p_category`, `p_sub`, `p_brand`, `p_price`, `d_price`, `m_price`, `p_desc`, `p_qty`, `p_image`) VALUES
(20000, 'llkjkhjh', '1', '1', '1', 1222, 222, 1000, 'fergegergerg', 33, 'a.jpg'),
(22342, 'sdsfsdf', '2', '2', '1', 3444, 444, 3000, 'gfegefgfeg', 33, 'a.jpg'),
(132323, 'regeg', '2', '1', '1', 3333, 33, 3300, 'ererewre', 0, 'a.jpg'),
(34456465, 'terere', '1', '2', '1', 400, 50, 350, 'sdfgsdgs', 45, 'a.jpg'),
(34456467, 'shirt mad', '1', '2', '1', 100, 20, 80, 'dhaskjfhkjdsahfkjlsahdfkjasdhfkjsdah', 0, 'carparts-home-icon2.png');

-- --------------------------------------------------------

--
-- Table structure for table `order_address`
--

CREATE TABLE `order_address` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_name` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `order_status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_address`
--

INSERT INTO `order_address` (`id`, `order_id`, `user_id`, `order_name`, `city`, `address`, `total_amount`, `order_status`) VALUES
(2, 3255046, 9, 'r3r', 'wrer', 'fgdfg', 280, 'cancelled'),
(4, 874711, 14, 'new@gmail.com', 'monteal', 'jadslkfjdlakfjkladjf', 2800, 'confirmed'),
(5, 183833, 9, 'noew', 'laval', 'Please order on time ', 5900, 'confirmed'),
(6, 1661117, 0, '', '', '', 2700, 'confirmed'),
(7, 8185735, 22, 'sdf', 'dfdfdf', 'dfdfdfdf', 350, 'confirmed'),
(8, 3934755, 23, 'hhh', 'hhhh', 'hhhhh', 549, 'confirmed'),
(9, 148621, 23, 'dasfd', 'dfdfq', 'dfmndmfn', 900, 'confirmed'),
(10, 5517752, 14, 'last', 'one', 'hsadfjhjahsdkjf', 945, 'cancelled'),
(11, 5839380, 14, 'rrr', 'mon', 'sjakfjdalkfjds', 3849, 'confirmed'),
(12, 9423924, 14, 'mizan', 'montreal', 'dsfjakjkasdjflkasf', 945, 'confirmed'),
(13, 6703045, 14, 'sasad', 'JKHJ', 'jjhjh', 1800, 'confirmed'),
(14, 1088832, 24, 'Mizan', 'Montreal', '123, blvd abc', 2500, 'confirmed'),
(15, 517604, 24, 'Mizan', 'Montreal', '123, blvd abc', 2500, 'cancelled'),
(16, 8275782, 24, 'Mizan', 'Montreal', '123, blvd abc', 2500, 'confirmed'),
(17, 410154, 24, 'Mizan', 'Montreal', '123, blvd abc', 2500, 'confirmed'),
(18, 1901685, 24, 'Mizan', 'Montreal', '123, blvd abc', 2500, 'cancelled');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `pro_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `pro_id`, `qty`) VALUES
(3, 3255046, 2, 1),
(4, 3172984, 1, 8),
(5, 3172984, 2, 5),
(6, 874711, 2, 1),
(7, 183833, 64, 1),
(8, 183833, 63, 1),
(9, 183833, 62, 1),
(10, 1661117, 62, 1),
(11, 1661117, 1, 1),
(12, 1661117, 60, 1),
(13, 8185735, 34456465, 1),
(14, 3934755, 58, 1),
(15, 148621, 60, 1),
(16, 5517752, 59, 1),
(17, 5839380, 58, 1),
(18, 5839380, 132323, 1),
(19, 9423924, 59, 1),
(20, 6703045, 60, 2),
(21, 1088832, 64, 1),
(22, 517604, 64, 1),
(23, 8275782, 64, 1),
(24, 410154, 64, 1),
(25, 1901685, 64, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `p_name` varchar(250) NOT NULL,
  `p_category` varchar(250) NOT NULL,
  `p_sub` varchar(255) NOT NULL,
  `p_brand` varchar(250) NOT NULL,
  `p_price` int(11) NOT NULL,
  `p_desc` varchar(5000) NOT NULL,
  `p_qty` int(11) NOT NULL,
  `p_image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `p_name`, `p_category`, `p_sub`, `p_brand`, `p_price`, `p_desc`, `p_qty`, `p_image`) VALUES
(2, 'Solid Men Mandarin Collar Green T-Shirt', '1', '13', '22', 2800, 'Fine Original tshirt', 8, 'product-2.png'),
(58, 'Men Mandarin Collar  Black T-Shirt', '1', '13', '1', 549, '', 500, 'product-3.png'),
(59, 'Printed Pure Cotton White Top ', '2', '2', '22', 945, 'Fine Original Product.', 91, 'women-1.png'),
(60, 'Women Printed Black Top', '2', '2', '1', 900, '', 32, 'women-2.png'),
(63, 'Slim Men Blue Jeans', '1', '3', '1', 1800, 'Tommy Slim Men Blue Jeans', 900, 'jens-1.png'),
(64, 'Slim Men Grey Jeans', '1', '3', '22', 2500, 'Fine Original Brand Grey Jeans.', 500, 'jens-2.png');

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`id`, `cat_id`, `name`) VALUES
(2, 2, 'Tops'),
(3, 1, 'Jeans'),
(13, 1, 'T-Shirt'),
(25, 2, 'Jeans');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `forgotrequest`
--
ALTER TABLE `forgotrequest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offerproducts`
--
ALTER TABLE `offerproducts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_address`
--
ALTER TABLE `order_address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `c_id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `forgotrequest`
--
ALTER TABLE `forgotrequest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `offerproducts`
--
ALTER TABLE `offerproducts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34456468;

--
-- AUTO_INCREMENT for table `order_address`
--
ALTER TABLE `order_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
