<footer id="footer" style="margin-top:10px;"><!--Footer-->
		
		
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-xs-6 col-lg-3">
						<div class="single-widget">
 							<h2>About Us</h2>
 							<p>We started this company to share our ideas of new cloths and provide you with the best garments possible.</p>
 							<h5>Contact Us</h5>
							<ul class="nav nav-pills nav-stacked">
 								<li><a href="AboutUs.php"><i class="fa fa-phone"></i> +1(514)-145-4654</a></li>
								 <li><a href="ContactUs.php"><i class="fa fa-envelope-o"></i> info@finecloth.com</a></li>
 							</ul>
						</div>
					</div>

					<div class="col-xs-6 col-lg-3">
						<div class="single-widget">
							<h2>Product</h2>
							<ul class="nav nav-pills nav-stacked">
 								<li><a href="shop.php?sub=1">Men Shirts </a></li>
                                                                <li><a href="shop.php?sub=3">Men Jeans</a></li>
								<li><a href="shop.php?sub=2">Women Tops</a></li>
                                                                <li><a href="shop.php?sub=13">Women Jeans</a></li>
								
 							</ul>
						</div>
					</div>

					<div class="col-xs-6 col-lg-3">
						<div class="single-widget">
							<h2>Information</h2>
							<ul class="nav nav-pills nav-stacked">
 								<li><a href="AboutUs.php">About Us</a></li>
								 <li><a href="ContactUs.php">Contact Us</a></li>
								 <li><a href="#">Offers</a></li>
								 <li><a href="#">Terms & Condition</a></li>
 							</ul>
						</div>
					</div>

					<div class="col-xs-6 col-lg-3">
						<div class="single-widget">
							<h2>Keep In Touch</h2>
							<ul class="nav nav-pills nav-stacked social-icon">
								<li class="fb"><a href="https://www.facebook.com" target="_blank"><i class="fa fa-facebook-square"></i> </a></li>
								<li class="ut"><a href="https://www.youtube.com" target="_blank"><i class="fa fa-youtube-square"></i> </a></li>
								<li class="ins"><a href="https://www.intagram.com" target="_blank"><i class="fa fa-instagram"></i></a></li>
								<li class="twitter"><a href="https://www.twitter.com" target="_blank"><i class="fa fa-twitter-square"></i></a></li>						 
 							</ul>
 							<h5 style="margin-top:15px">Contact Us</h5>
 							<img src="images/payments.png" style="width:100%;">
						</div>
					</div>
					
					<div class="col-xs-6 col-lg-3">
						<div class="single-widget">
 							
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © 2021 Fine Clothes Inc. All rights reserved.</p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	

  
  
</body>
</html>
 