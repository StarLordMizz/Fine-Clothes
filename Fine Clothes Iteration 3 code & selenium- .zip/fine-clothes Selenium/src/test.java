import static org.junit.Assert.*;

import org.junit.Test;

public class test {

	@Test
	public void test() {
		
		// t_01 t1=new t_01();
		//t1.test01();
		
		//t_02 t2=new t_02();
		//t2.test02();
		
		//t_03 t3=new t_03();
		//t3.test03();
		
		//t_04 t4=new t_04();
		//t4.test04();
		
		//t_05 t5=new t_05();
		//t5.test05();
		
		//t_06 t6=new t_06();
		//t6.test06();
		
		//t_07 t7=new t_07();
		//t7.test07();
		
		//t_08 t8=new t_08();
		//t8.test08();
		
		//t_09 t9=new t_09();
		//t9.test09();
		
		//t_10 t10=new t_10();
		//t10.test10();
		
		//t_11 t11=new t_11();
		//t11.test11();
		
		//t_12 t12=new t_12();
		//t12.test12();
		
		//t_13 t13=new t_13();
		//t13.test13();
		
		//t_14 t14=new t_14();
		//t14.test14();
		
	     //t_15 t15=new t_15();
		//t15.t_15();
		
		//t_16 t16=new t_16();
		//t16.t_16();
		
		//t_17 t17=new t_17();
		//t17.t_17();
		
		//t_18 t18=new t_18();
		//t18.t_18();
		
		//t_19 t19=new t_19();
		//t19.t_19();
		
		//t_20 t20=new t_20();
		//t20.t_20();
		
		t_21 t21=new t_21();
	    t21.t_21();
		
		//t_22 t22=new t_22();
	//	t22.t_22();
		
		//t_23 t23=new t_23();
		//t23.t_23();
		
		//t_24 t24=new t_24();
		//t24.t_24();
		
		//t_25 t25=new t_25();
		//t25.t_25();

	}

}
