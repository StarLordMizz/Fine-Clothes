import org.openqa.selenium.By;
	import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import java.util.concurrent.TimeUnit;
	import org.junit.Assert;
public class t_12 {
public void test12() {
	WebDriver driver;
	System.setProperty("webdriver.chrome.driver","C:\\Chromedriver\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("http://localhost/fine-clothes/index.php");
	driver.findElement(By.xpath("/html/body/header/div[3]/div/div/div[1]/div[2]/ul/li[4]/a")).click();
	driver.findElement(By.name("name")).sendKeys("mizan");

	//driver.findElement(By.name("email")).sendKeys("mizan@gmail.com");
	driver.findElement(By.id("message")).sendKeys("sfdgg");

	driver.findElement(By.name("submit")).click();

}}