import org.openqa.selenium.By;
	import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import java.util.concurrent.TimeUnit;
	import org.junit.Assert;
public class t_02 {
public void test02() {
	WebDriver driver;
	System.setProperty("webdriver.chrome.driver","C:\\Chromedriver\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("http://localhost/fine-clothes/index.php");
	driver.findElement(By.xpath("/html/body/header/div[2]/div/div/div[2]/div/ul/li[3]/a")).click();
	driver.findElement(By.id("username")).sendKeys("");
	driver.findElement(By.id("password")).sendKeys("123456");
	driver.findElement(By.id("login-submit")).click();
	String text1=driver.switchTo().alert().getText();
	driver.switchTo().alert().accept();
	
	String text2="Email or Password incorrect";
	Assert.assertEquals(text2, text1);
	System.out.println("Success");
}
}
