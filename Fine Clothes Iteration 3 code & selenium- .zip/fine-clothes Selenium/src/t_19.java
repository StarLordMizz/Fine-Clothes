import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import java.util.concurrent.TimeUnit;
	import org.junit.Assert;
public class t_19 {
public void t_19() {
	WebDriver driver;
	System.setProperty("webdriver.chrome.driver","C:\\Chromedriver\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("http://localhost/fine-clothes/index.php");
	driver.manage().window().maximize();
	driver.findElement(By.xpath("/html/body/header/div[2]/div/div/div[2]/div/ul/li[3]/a")).click();
	try
	{
	    Thread.sleep(2000);
	}
	catch(InterruptedException ex)
	{
	    Thread.currentThread().interrupt();
	}
	driver.findElement(By.id("username")).sendKeys("m@gmail.com");
	driver.findElement(By.id("password")).sendKeys("123456");
	driver.findElement(By.id("login-submit")).click();
	driver.switchTo().alert().accept();
	
	driver.findElement(By.xpath("/html/body/header/div[2]/div/div/div[2]/div/ul/li[1]/a")).click();
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,250)", "");
	
	try
	{
	    Thread.sleep(2000);
	}
	catch(InterruptedException ex)
	{
	    Thread.currentThread().interrupt();
	}
	
	System.out.println("Success");
	driver.quit();
	
}
}
