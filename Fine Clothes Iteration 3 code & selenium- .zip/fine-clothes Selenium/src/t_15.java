import org.openqa.selenium.By;
	import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import java.util.concurrent.TimeUnit;
	import org.junit.Assert;
public class t_15 {
public void t_15() {
	WebDriver driver;
	System.setProperty("webdriver.chrome.driver","C:\\Chromedriver\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("http://localhost/fine-clothes/index.php");
	
	driver.manage().window().maximize();
	driver.findElement(By.xpath("/html/body/header/div[2]/div/div/div[2]/div/ul/li[3]/a")).click();
	driver.findElement(By.id("username")).sendKeys("m@gmail.com");
	driver.findElement(By.id("password")).sendKeys("123456");
	driver.findElement(By.id("login-submit")).click();
	
	try
	{
	    Thread.sleep(2000);
	}
	catch(InterruptedException ex)
	{
	    Thread.currentThread().interrupt();
	}
	
	driver.switchTo().alert().accept();
	driver.findElement(By.xpath("/html/body/header/div[3]/div/div/div[1]/div[2]/ul/li[2]/a")).click();
	driver.findElement(By.xpath("/html/body/section/div/div/div[2]/div/div[1]/div/div[1]/div/a[2]")).click();
	
	try
	{
	    Thread.sleep(2000);
	}
	catch(InterruptedException ex)
	{
	    Thread.currentThread().interrupt();
	}
	
	driver.findElement(By.xpath("/html/body/header/div[2]/div/div/div[2]/div/ul/li[2]/a")).click();
	
	
	try
	{
	    Thread.sleep(2000);
	}
	catch(InterruptedException ex)
	{
	    Thread.currentThread().interrupt();
	}
	
	System.out.println("Success");
	driver.quit();
}
}
