    import org.openqa.selenium.By;
	import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import java.util.concurrent.TimeUnit;
	import org.junit.Assert;
	
	
public class t_07 {
public void test07() {

	WebDriver driver;
	System.setProperty("webdriver.chrome.driver","C:\\Chromedriver\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("http://localhost/fine-clothes/index.php");
	driver.findElement(By.xpath("/html/body/header/div[2]/div/div/div[2]/div/ul/li[3]/a")).click();
	
	try
	{
	    Thread.sleep(2000);
	}
	catch(InterruptedException ex)
	{
	    Thread.currentThread().interrupt();
	}
	driver.findElement(By.id("register-form-link")).click();
	//new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.id("username"))).click();
	driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("mizan01");
	try
	{
	    Thread.sleep(2000);
	}
	catch(InterruptedException ex)
	{
	    Thread.currentThread().interrupt();
	}
	//driver.findElement(By.id("email")).sendKeys("mizan@gmail.com");
	driver.findElement(By.id("password1")).sendKeys("123456");
	driver.findElement(By.id("confirm-password")).sendKeys("123456");
	driver.findElement(By.id("register-submit")).click();
	

	String text1=driver.switchTo().alert().getText();
	driver.switchTo().alert().accept();
	
	String text2="Please fill all fields ";
	Assert.assertEquals(text2, text1);
	System.out.println("Success");
}
}
